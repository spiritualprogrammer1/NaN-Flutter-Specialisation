import 'package:prepa_app/models/Adresse.dart';
import 'package:prepa_app/models/Type.dart' as m;

class Restaurant {
  int id;
  String nom;
  String cigle;
  dynamic numero;
  String photo;
  m.Type type;
  Adresse adresse;
  bool local;

  Restaurant({this.id, this.nom, this.adresse, this.type,
      this.numero, this.photo, this.cigle, this.local: false});

  factory Restaurant.fromJson(Map<String, dynamic> json) {
    return Restaurant(
      id: json['id'],
      nom: json['name'],
      cigle: json['cigle'],
      numero: json['tel'],
      photo: json['photo'],
      type: json['type'] == null ? m.Type() : m.Type.fromJson(json['type']),
      adresse: json['address'] == null ? Adresse() : Adresse.fromJson(json['address'])
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': nom,
      'photo': photo,
      'cigle': cigle,
      'tel': numero,
      'type': type.id
    };
  }
}