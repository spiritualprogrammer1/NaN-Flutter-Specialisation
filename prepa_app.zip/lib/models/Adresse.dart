
class Adresse {
  final int id;
  final String commune;
  final String ville;
  final dynamic longitude;
  final dynamic latitude;

  Adresse({this.id, this.commune, this.ville, this.longitude, this.latitude});

  factory Adresse.fromJson(Map<String, dynamic> json) {
    return Adresse(
      id: json['id'],
      commune: json['commune'],
      ville: json['ville'],
      longitude: json['logitude'],
      latitude: json['latitude'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'commune': commune,
      'ville': ville,
      'logitude': longitude,
      'latitude': latitude
    };
  }
}