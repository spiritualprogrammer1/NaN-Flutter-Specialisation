

class Type {
  final int id;
  final String nom;

  Type({this.id, this.nom});

  factory Type.fromJson(Map<String, dynamic> json) {
    return Type(
      id: json['id'],
      nom: json['name']
    );
  }
}