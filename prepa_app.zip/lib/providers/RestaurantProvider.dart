import 'dart:convert';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:prepa_app/helpers/DatabaseHelper.dart';
import 'package:prepa_app/models/Restaurant.dart';
import 'package:sqflite/sqflite.dart';

class RestaurantProvider with ChangeNotifier {
  List<Restaurant> _restaurants = [];

  List<Restaurant> get restaurants => [..._restaurants];

  final baseUrl = 'http://192.168.50.85:1337/resto';

  RestaurantProvider() {
    initResto();
  }

  void initResto() async {

    var connectivityResult = await (Connectivity().checkConnectivity());
    if(connectivityResult ==  ConnectivityResult.none) {
      loadOffline();
    } else {
      loadOnline();
    }

    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) async{
      if(result == ConnectivityResult.none) return;
      print('change');
      Database db = await DatabaseHelper().db;
      List<Map> res = await db.rawQuery("SELECT *, r.id as idR, t.id as idT, a.id as idA, r.name as nameR, t.name as nameT FROM resto r LEFT JOIN address a ON r.address = a.id LEFT JOIN type t ON t.id = r.type");
      for(Map<String, dynamic>json in res) {
        Map<String, dynamic> refacto = refactor(json);
        Restaurant resto = Restaurant.fromJson(refacto);
        resto.local = true;
        await _insertOnline(resto, put: false);
      }
      loadOnline();
      await db.rawDelete("DELETE FROM RESTO");
      notifyListeners();
    });

  }

  Map<String, dynamic> refactor(Map<String, dynamic> json)  {
     return {
      'id': json['idR'],
      'name': json['nameR'],
      'cigle': json['cigle'],
      'tel': json['tel'],
      'photo': json['photo'],
       'update': json['modif'] == 1,
      'type': {
        'id': json['idT'],
        'name': json['nameT']
      },
      'address': {
        'id': json['idA'],
        'commune': json['commune'],
        'ville': json['ville'],
        'logitude': json['logitude'],
        'latitude': json['latitude'],
      }

    };
  }

  void loadOffline({clear: false}) async {
    try {
      if(clear) _restaurants.clear();
      Database db = await DatabaseHelper().db;
      List<Map> res = await db.rawQuery("SELECT *, r.id as idR, t.id as idT, a.id as idA, r.name as nameR, t.name as nameT FROM resto r LEFT JOIN address a ON r.address = a.id LEFT JOIN type t ON t.id = r.type");
      for(Map<String, dynamic>json in res) {
        Map<String, dynamic> refacto = refactor(json);
        Restaurant resto = Restaurant.fromJson(refacto);
        resto.local = true;
        _restaurants.add(resto);
      }
      notifyListeners();
    } catch(e) {
      print(e);
    }
  }

  void loadOnline({bool only: false}) async {
    try {
      final res = await http.get(baseUrl);
      _restaurants.clear();
      for(Map<String, dynamic>json in jsonDecode(res.body)) {
        Restaurant resto = Restaurant.fromJson(json);
        _restaurants.add(resto);
      }
      notifyListeners();
    } catch(e) {
      print(e);
      if(!only) loadOffline();
    }
  }

  void insert(Restaurant restaurant) async{
    var connectivityResult = await (Connectivity().checkConnectivity());
    if(connectivityResult ==  ConnectivityResult.none) {
      _insertOffline(restaurant, add: restaurant.id != null);
    } else {
      _insertOnline(restaurant);
    }
  }

  Future<void> _insertOffline(Restaurant resto, {add: false}) async{
    Database db = await DatabaseHelper().db;
    if(add) _restaurants.add(resto);
    resto.local = true;
    await db.transaction((txn) async {
      int idA = await txn.rawInsert("INSERT OR REPLACE INTO address(id, ids, commune, ville, logitude, latitude) VALUES((SELECT ID FROM type WHERE ids = ?),?,?,?,?,?)", [
        resto.adresse.id, resto.adresse.id, resto.adresse.commune, resto.adresse.ville, resto.adresse.longitude, resto.adresse.latitude
      ]);
      int idT = await txn.rawInsert("INSERT OR REPLACE INTO type(id, ids, name) VALUES((SELECT ID FROM type WHERE ids = ?) ,?,?)", [
        resto.type.id ,resto.type.id, resto.type.nom
      ]);
      await txn.rawInsert("INSERT OR REPLACE INTO resto(id, ids, name, photo, cigle, tel, address, type) VALUES((SELECT ID FROM type WHERE ids = ?), ?,?,?,?,?,?,?)", [
        resto.id, resto.id, resto.nom, resto.photo, resto.cigle, resto.numero, idA, idT
      ]);
    });
    notifyListeners();
  }

  Future<void> _insertOnline(Restaurant restaurant, {bool put: true}) async {
    print(restaurant.id);
    if(restaurant.id != null && put) {
      final res1 = await http.put('http://192.168.50.85:1337/address/${restaurant.adresse.toMap()}', body: jsonEncode(restaurant.adresse.toMap()));

      Map<String, dynamic> send = restaurant.toMap();
      send['address'] = jsonDecode(res1.body)['id'];
      final res2 = await http.put('$baseUrl/${restaurant.id}', body: jsonEncode(send));
    } else {
      print('upload on 2');
      final res1 = await http.post('http://192.168.50.85:1337/address', body: jsonEncode(restaurant.adresse.toMap()));
      Map<String, dynamic> send = restaurant.toMap();
      send['address'] = jsonDecode(res1.body)['id'];
      final res2 = await http.post(baseUrl, body: jsonEncode(send));
      _restaurants.add(restaurant);
    }
    notifyListeners();
  }

  void delete(Restaurant resto) async{
    _restaurants.remove(resto);
    notifyListeners();
    final res = await http.delete('$baseUrl/${resto.id}');
    print(res.body);
  }
}