import 'dart:convert';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/foundation.dart';
import 'package:prepa_app/helpers/DatabaseHelper.dart';
import 'package:prepa_app/models/Type.dart' as m;
import 'package:http/http.dart' as http;
import 'package:sqflite/sqflite.dart';

class TypeProvider with ChangeNotifier {

  List<m.Type> _types = [];

  List<m.Type> get types => [..._types];

  TypeProvider() {
    initType();
  }

  void initType() async {
    print('load type');
    var connectivityResult = await (Connectivity().checkConnectivity());
    if(connectivityResult ==  ConnectivityResult.none) {
      _loadOffline();
    } else {
      _loadOnline();
    }
  }

  void _loadOffline() async{
    try {
      Database db = await DatabaseHelper().db;
      List<Map> res = await db.rawQuery("SELECT name, ids as id FROM type");
      for(Map<String, dynamic>json in res) {
        _types.add(m.Type.fromJson(json));
      }
      notifyListeners();
    } catch(e) {
      print(e);
    }
  }

  void _loadOnline() async{
    try {
      List<int> save = [];
      final res = await http.get('http://192.168.50.85:1337/type');
      Database db = await DatabaseHelper().db;

      await db.transaction((txn) async {
        for(Map<String, dynamic>json in jsonDecode(res.body)) {
          m.Type type = m.Type.fromJson(json);
          _types.add(type);
          save.add(type.id);
          await txn.rawInsert("INSERT OR REPLACE INTO type(id, ids, name) VALUES((SELECT ID FROM type WHERE ids = ?) ,?,?)", [
            type.id ,type.id, type.nom
          ]);
        }
      });
      await db.rawDelete("DELETE FROM type WHERE ids NOT IN (?) AND ids IS NOT NULL", [save]);
      notifyListeners();
    } catch(e) {
      print('load offline');
      print(e);
      _loadOffline();
    }
  }
}