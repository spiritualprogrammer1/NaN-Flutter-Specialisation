import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper _databaseHelper = DatabaseHelper._internal();

  factory DatabaseHelper() {
    return _databaseHelper;
  }

  DatabaseHelper._internal();

  Database _db;

  Future<Database> get db async{
    if(_db != null) return _db;
    var databasePath = await getDatabasesPath();
    String path = join(databasePath, 'exam.db');
    //deleteDatabase(path);
    Database database = await openDatabase(path, version: 1, onCreate: (Database db, int version) async {
      await db.execute('''
        CREATE TABLE resto(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ids INTEGER,
          name TEXT,
          photo TEXT,
          cigle TEXT,
          tel TEXT,
          address INTEGER,
          type INTEGER
         )
        ''');
      await db.execute('''
        CREATE TABLE address(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ids INTEGER,
          commune TEXT,
          ville TEXT,
          logitude TEXT,
          latitude TEXT
         )
        ''');
      await db.execute('''
        CREATE TABLE type(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ids INTEGER,
          name TEXT
         )
        ''');
    });
    _db = database;
    return _db;
  }
}