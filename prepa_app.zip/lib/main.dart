import 'package:flutter/material.dart';
import 'package:prepa_app/pages/FormRestaurantPage.dart';
import 'package:prepa_app/pages/ListeRestaurantPage.dart';
import 'package:prepa_app/pages/LoginPage.dart';
import 'package:prepa_app/providers/RestaurantProvider.dart';
import 'package:prepa_app/providers/TypeProvider.dart';
import 'package:provider/provider.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
        providers: [
          ChangeNotifierProvider.value(value: TypeProvider()),
          ChangeNotifierProvider.value(value: RestaurantProvider()),
        ],
      child: MaterialApp(
        title: 'Flutter Demo',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        initialRoute: ListeRestaurantPage.routeName,
        routes: {
          ListeRestaurantPage.routeName: (ctx) => ListeRestaurantPage(),
          FormRestaurantPage.routeName: (ctx) => FormRestaurantPage(),
          LoginPage.routeName: (ctx) => LoginPage()
        },
      ),
    );
  }
}
