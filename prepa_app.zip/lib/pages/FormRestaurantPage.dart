import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:prepa_app/models/Adresse.dart';
import 'package:prepa_app/models/Restaurant.dart';
import 'package:prepa_app/models/Type.dart' as m;
import 'package:prepa_app/providers/RestaurantProvider.dart';
import 'package:prepa_app/providers/TypeProvider.dart';
import 'package:provider/provider.dart';

class FormRestaurantPage extends StatefulWidget {

  static const routeName = '/form';

  @override
  _FormRestaurantPageState createState() => _FormRestaurantPageState();
}

class _FormRestaurantPageState extends State<FormRestaurantPage> {

  GlobalKey<FormState> _fKey = GlobalKey();
  GlobalKey<ScaffoldState> _sKey = GlobalKey();

  List<String> villes = ['Abidjan', 'Yamoussoukro', 'Bouaké'];
  List<String> communes = ['Yoppougon', 'Cocody', 'Abobo'];

  TextEditingController _nom = TextEditingController();
  TextEditingController _numero = TextEditingController();
  TextEditingController _cigle = TextEditingController();
  TextEditingController _image = TextEditingController();

  String _ville;
  String _commune;
  m.Type _type;

  Restaurant restaurant;

  bool init = true;

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();
    if(init) {
      init = false;
      final Restaurant args = ModalRoute.of(context).settings.arguments;
      if(args == null) {
        restaurant = Restaurant();
      } else {
        restaurant = Provider.of<RestaurantProvider>(context).restaurants.firstWhere((r) => r.id == args.id);
        _nom.text = restaurant.nom;
        _numero.text = restaurant.numero.toString();
        _cigle.text = restaurant.cigle;
        _image.text = restaurant.photo;
        _ville = restaurant.adresse.ville;
        _commune = restaurant.adresse.commune;
        //_type = restaurant.type;
      }
    }
  }

  @override
  Widget build(BuildContext context) {

    final typeProvider = Provider.of<TypeProvider>(context);

    return Scaffold(
      key: _sKey,
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
          child: SingleChildScrollView(
            padding: EdgeInsets.all(10.0),
            child: Form(
              key: _fKey,
              child: Column(
                children: <Widget>[
                  Text('Remplisser le formulaire', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),),
                  SizedBox(height: 15.0,),
                  TextFormField(
                    controller: _nom,
                    validator: (val) {
                      if(val.isEmpty) {
                        return 'Choisissez un nom';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      hintText: 'Labelle',
                      filled: true,
                      fillColor: Colors.blue.withOpacity(0.5),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        borderSide: BorderSide.none
                      )
                    ),
                  ),
                  DropdownButton<String>(
                    hint: Text('Choissisez une ville'),
                    value: _ville,
                    items: villes.map((String val) {
                      return DropdownMenuItem(
                          child: Text(val),
                        value: val,
                      );
                    }).toList(),
                    onChanged: (String val) {
                      _ville = val;
                      setState((){});
                    },
                  ),
                  _ville == 'Abidjan' ? DropdownButton<String>(
                    hint: Text('Choissisez une commune'),
                    value: _commune,
                    items: communes.map((String val) {
                      return DropdownMenuItem(
                        child: Text(val),
                        value: val,
                      );
                    }).toList(),
                    onChanged: (String val) {
                      _commune = val;
                      setState((){});
                    },
                  ) : Container(),
                  DropdownButton<m.Type>(
                    hint: Text('Choissisez un type'),
                    value: _type,
                    items: typeProvider.types.map((m.Type val) {
                      return DropdownMenuItem(
                        child: Text(val.nom),
                        value: val,
                      );
                    }).toList(),
                    onChanged: (m.Type val) {
                      _type = val;
                      setState((){});
                    },
                  ),
                  TextFormField(
                    controller: _numero,
                    keyboardType: TextInputType.number,
                    validator: (val) {
                      /*RegExp regEx = RegExp(r"/^[04-9][0-9]{7}$/");
                      if(!regEx.hasMatch(val)) {
                        return 'Format du numéro invalide';
                      }*/
                      return null;
                    },
                    decoration: InputDecoration(
                      hintText: 'Numero de telephone',
                        filled: true,
                        fillColor: Colors.blue.withOpacity(0.5),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10.0)),
                            borderSide: BorderSide.none
                        )
                    ),
                  ),
                  Container(height: 10.0,),
                  TextFormField(
                    controller: _cigle,
                    validator: (val) {
                      if(val.isEmpty) {
                        return 'Entrer un cigle';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                        hintText: 'Cigle',
                        filled: true,
                        fillColor: Colors.blue.withOpacity(0.5),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10.0)),
                            borderSide: BorderSide.none
                        )
                    ),
                  ),
                  Container(height: 10.0,),
                  TextFormField(
                    controller: _image,
                    validator: (val) {
                      if(val.isEmpty) {
                        return 'Entrer une image';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                        hintText: 'Image',
                        filled: true,
                        fillColor: Colors.blue.withOpacity(0.5),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10.0)),
                            borderSide: BorderSide.none
                        )
                    ),
                  ),
                  /*RaisedButton(
                      child: Text('Localiser'),
                      onPressed: () {

                      }
                  ),*/
                  RaisedButton(
                    child: Text('Enregistrer'),
                      onPressed: () {
                        save();
                        Navigator.pop(context);
                      }
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void save() {
    Duration duration = Duration(seconds: 2);
    if(_fKey.currentState.validate()) {
      if(_ville == null) {
        _sKey.currentState.showSnackBar(SnackBar(content: Text('Veuiller selectionner une ville'), duration: duration,));
      } else if(_ville == 'Abidjan' && _commune == null) {
        _sKey.currentState.showSnackBar(SnackBar(content: Text('Veuiller selectionner une commune'), duration: duration,));
      } else if(_type == null) {
        _sKey.currentState.showSnackBar(SnackBar(content: Text('Veuiller selectionner un type'), duration: duration,));
      } else {
        restaurant.nom = _nom.text;
        restaurant.cigle = _cigle.text;
        restaurant.numero = _numero.text;
        restaurant.photo = _image.text;
        restaurant.type = _type;
        restaurant.adresse = Adresse(
          latitude: 25465.05,
          longitude: 87652.042,
          commune: _commune,
          ville: _ville
        );
        Provider.of<RestaurantProvider>(context).insert(restaurant);
      }
    }
  }
}
