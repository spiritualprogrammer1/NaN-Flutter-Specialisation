import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:prepa_app/models/Restaurant.dart';
import 'package:prepa_app/pages/FormRestaurantPage.dart';
import 'package:prepa_app/providers/RestaurantProvider.dart';
import 'package:provider/provider.dart';

class ListeRestaurantPage extends StatefulWidget {

  static const routeName = '/';

  @override
  _ListeRestaurantPageState createState() => _ListeRestaurantPageState();
}

class _ListeRestaurantPageState extends State<ListeRestaurantPage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: <Widget>[
          FlatButton(
              onPressed: () => Provider.of<RestaurantProvider>(context).loadOffline(clear: true),
              child: Text('Offline', style: TextStyle(color: Colors.white))
          ),
          FlatButton(
              onPressed: () => Provider.of<RestaurantProvider>(context).loadOnline(only: true),
              child: Text('Online', style: TextStyle(color: Colors.white))
          ),
        ],
      ),
      body: Consumer<RestaurantProvider>(
          builder: (_, restaurantProvider, __) {
            return ListView.builder(
              itemCount: restaurantProvider.restaurants.length,
              itemBuilder: (ctx, i) {
                Restaurant restaurant = restaurantProvider.restaurants[i];
                return Card(
                  child: Container(
                    width: double.infinity,
                    margin: EdgeInsets.symmetric(horizontal: 10.0),
                    height: 160,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              Navigator.pushNamed(context, FormRestaurantPage.routeName, arguments: restaurant);
                            },
                            child: CachedNetworkImage(
                              imageUrl: restaurant.photo,
                              fit: BoxFit.cover,
                              placeholder: (ctx, str) => Center(
                                child: CircularProgressIndicator(),
                              ),
                              errorWidget: (ctx, str, obj)=> Center(
                                child: Icon(Icons.error, color: Colors.red,),
                              ),
                            ),
                          )
                        ),
                        Expanded(
                          flex: 3,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                Text(restaurant.nom, style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),),
                                Text("Numero: ${restaurant.numero}"),
                                Text("Cigle: ${restaurant.cigle}"),
                                Text("Type: ${restaurant.type == null ? '' : restaurant.type.nom}"),
                                Row(
                                  children: <Widget>[
                                    IconButton(
                                        icon: Icon(Icons.delete),
                                        color: Colors.red,
                                        onPressed: () {
                                          Provider.of<RestaurantProvider>(context).delete(restaurant);
                                        }
                                    ),
                                    Icon(
                                      Icons.file_upload,
                                      color: (restaurant.local) ? Colors.red : Colors.green,
                                    )
                                  ],
                                )
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                );
              },
            );
          }
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: () => Navigator.pushNamed(context, FormRestaurantPage.routeName),
        child: Icon(Icons.add),
      ),
    );
  }
}
