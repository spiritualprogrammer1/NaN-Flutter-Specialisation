import 'package:flutter/material.dart';
import 'package:prepa_app/pages/ListeRestaurantPage.dart';

class LoginPage extends StatelessWidget {

  static const routeName = '/login';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Form(
          child: Column(
            children: <Widget>[
              TextFormField(),
              TextFormField(),
              RaisedButton(
                  onPressed: () => Navigator.pushNamed(context, ListeRestaurantPage.routeName)
              )
            ],
          ),
        ),
      ),
    );
  }
}
